
public enum Platform {

	XB, PS, PC, IO, AN

}
