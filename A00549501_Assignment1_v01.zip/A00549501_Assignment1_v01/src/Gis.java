

/**
 * Driver for Games Information System.
 * @author Brendan Woods - A00549501
 *
 */
public class Gis {

	/**
	 * Default constructor. 
	 */
	public Gis() {
		// TODO Auto-generated constructor stub
	}

	/*
	 * @param args
	 */
	public static void main(String[] args) {
		Persona persona = new Persona(01, "44", "jakhamma", "XB");
		persona.printInfo();
		

	}

}


//TODO check no warnings.
//Activity logged to #Gis.log including exceptions
//All classes should have 2 constructors. one of which implements the set methods 
//All suitable set methods should have validation where necessary.